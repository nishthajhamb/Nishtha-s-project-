import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("data/forbes.csv")

# Feature engineering
df['PrevClose'] = df['Close'].shift(1)
df['MA5'] = df['Close'].rolling(5).mean()
df['MA10'] = df['Close'].rolling(10).mean()
df['Target'] = (df['Close'].shift(-1) > df['Close']).astype(int)
df.dropna(inplace=True)

# Define features
features = ['Open', 'High', 'Low', 'Close', 'Volume', 'PrevClose', 'MA5', 'MA10']
X = df[features]
y = df['Target']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# Evaluate
y_pred = model.predict(X_test_scaled)
report = classification_report(y_test, y_pred)
print(report)

with open("data/model_metrics.txt", "w") as f:
    f.write("Train Accuracy: {:.2f}\n".format(model.score(X_train_scaled, y_train)))
    f.write("Test Accuracy: {:.2f}\n".format(model.score(X_test_scaled, y_test)))
    f.write("\nClassification Report:\n")
    f.write(report)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()
plt.title("Confusion Matrix")
plt.savefig("data/confusion_matrix.png")

# Feature importance
plt.figure()
plt.barh(features, model.feature_importances_)
plt.title("Feature Importance")
plt.tight_layout()
plt.savefig("data/feature_importance.png")

# ROC Curve
fpr, tpr, _ = roc_curve(y_test, model.predict_proba(X_test_scaled)[:,1])
roc_auc = auc(fpr, tpr)
plt.figure()
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.tight_layout()
plt.savefig("data/roc_curve.png")
