import pandas as pd
import os

# Path to your CSV folder
input_dir = '/mnt/c/Users/username/Downloads/archive/stock_market_data/forbes2000/csv'
output_file = '/mnt/c/Users/username/Downloads/archive/stock_market_data/forbes.csv'

# Initialize an empty list to collect DataFrames
dataframes = []

# Loop through all CSV files
for filename in os.listdir(input_dir):
    if filename.endswith(".csv"):
        filepath = os.path.join(input_dir, filename)
        try:
            df = pd.read_csv(filepath)

            # Add 'ticker' from filename
            df['ticker'] = filename.replace('.csv', '')

            # Optional: force consistent column order if needed
            expected_cols = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume']
            if all(col in df.columns for col in expected_cols):
                df = df[expected_cols + ['ticker']]
                dataframes.append(df)
            else:
                print(f"⚠️ Skipping {filename}: missing expected columns")

        except Exception as e:
            print(f" Failed to read {filename}: {e}")

# Merge all DataFrames
if dataframes:
    merged_df = pd.concat(dataframes, ignore_index=True)
    merged_df.to_csv(output_file, index=False)
    print(f" Merged {len(dataframes)} files into {output_file} with {len(merged_df)} rows.")
else:
    print(" No valid files were merged.")
