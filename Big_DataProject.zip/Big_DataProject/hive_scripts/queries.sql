-- Create external table
CREATE EXTERNAL TABLE forbes_data (
    date STRING,
    open FLOAT,
    high FLOAT,
    low FLOAT,
    close FLOAT,
    volume FLOAT,
    ticker STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hive/warehouse/forbes_data';

-- Summary stats: average volume
SELECT AVG(volume) FROM forbes_data;

-- Most frequent ticker
SELECT ticker, COUNT(*) AS count
FROM forbes_data
GROUP BY ticker
ORDER BY count DESC
LIMIT 5;

-- Highest closing price
SELECT date, close
FROM forbes_data
ORDER BY close DESC
LIMIT 1;
