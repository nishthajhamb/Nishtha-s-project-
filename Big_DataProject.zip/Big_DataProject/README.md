# Forbes Stock Data Big Data Analysis Project

This project applies Big Data and Machine Learning techniques to historical stock data from Forbes-listed companies. The process includes ingestion, transformation, Hive-based analytics, and machine learning modeling using a Docker-based Spark-Hive environment.

## 📁 Project Structure

- `forbes.csv` — Raw stock price dataset
- `feature_importance.png` — Feature importance plot from the trained model
- `confusion_matrix.png` — Confusion matrix visualizing prediction performance
- `roc_curve.png` — ROC curve showing model performance
- `model_metrics.txt` — Detailed model evaluation metrics

## 🔧 Technologies Used

- Apache Spark (PySpark)
- Apache Hive
- Docker
- Pandas
- Scikit-learn
- Matplotlib

## 🧪 Machine Learning Model

- **Model:** Random Forest Classifier
- **Target:** Predict if the next day's closing price will be higher (`1`) or not (`0`)
- **Features:** Open, High, Low, Close, Volume, Previous Close, 5-day MA, 10-day MA
- **Performance:**
  - Train Accuracy: 60%
  - Test Accuracy: 60%

## 📊 Visualizations

- Feature importance plot shows which variables influenced prediction.
- Confusion matrix evaluates how well the model classifies rising vs falling days.
- ROC curve (if implemented) helps visualize the trade-off between TPR and FPR.

## ⚙️ Setup Instructions

1. Clone the repository
2. Place the data and scripts in a Docker-based Spark-Hive environment
3. Run Jupyter or PySpark shell to train and evaluate the model

## 📌 Notes

- Dataset was cleaned and processed using Pandas in PySpark container.
- Model evaluation shows moderate performance; improvements may include hyperparameter tuning or advanced models like XGBoost.
